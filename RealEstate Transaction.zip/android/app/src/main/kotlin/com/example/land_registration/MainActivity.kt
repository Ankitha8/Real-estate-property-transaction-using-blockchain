package com.example.land_registration

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
